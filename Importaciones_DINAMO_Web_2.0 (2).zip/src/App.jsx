import React from 'react';
const brand = { blue:'#0B5FFF', graphite:'#111827', neon:'#A3E635' };
export default function App(){
  return (<div>
    <header>
      <div className="container" style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'14px 16px'}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <div style={{height:36,width:36,borderRadius:12,display:'grid',placeItems:'center',background:brand.blue,color:'#fff',fontWeight:800}}>D</div>
          <div style={{fontWeight:800}}>Importaciones <span style={{color:brand.blue}}>DINAMO</span></div>
        </div>
        <nav className="hide-sm">
          <a href="#beneficios">Beneficios</a><a href="#como">Cómo funciona</a><a href="#servicios">Servicios</a><a href="#politicas">Políticas</a><a href="#contacto">Contacto</a>
        </nav>
        <a href="#contacto" className="btn btn-primary">Cotizar ahora</a>
      </div>
    </header>
    <section className="hero">
      <div className="container" style={{display:'grid',gridTemplateColumns:'1.2fr 1fr',gap:24,padding:'64px 0'}}>
        <div>
          <div className="badge">Importaciones genuinas</div>
          <h1 style={{fontSize:42,lineHeight:1.2,margin:'12px 0'}}>Importaciones genuinas a precios bajos, <span style={{color:brand.blue}}>entregas en 7–12 días</span>.</h1>
          <p style={{color:'#374151'}}>Mayoristas (B2B) y Personal Shopper (B2C). Transparencia total: costo + comisión + envío 13%.</p>
          <div style={{display:'flex',gap:12,marginTop:18}}>
            <a className="btn btn-primary" href="https://wa.me/51929554806" target="_blank" rel="noreferrer">Cotizar ahora por WhatsApp</a>
            <a href="#beneficios" className="btn btn-outline">Ver beneficios</a>
          </div>
          <div style={{marginTop:8,fontSize:12,color:'#6B7280'}}>*Electrónicos con DOA 7 días. Apparel sin cambios por talla (asesoría previa).</div>
        </div>
        <div className="card">
          <h3 style={{marginTop:0}}>Transparencia de costos</h3>
          <ul style={{marginTop:8,lineHeight:1.8}}>
            <li>• B2B: costo proveedor + flete real + handling + margen bajo.</li>
            <li>• B2C: costo proveedor + comisión + <strong>envío 13%</strong> + handling.</li>
            <li>• Pagos: 50/50 en B2B. Comprobantes electrónicos.</li>
          </ul>
          <a className="btn btn-outline" href="/Calculadora_Precios_Importador.xlsx" style={{marginTop:8,display:'inline-block'}}>Descargar calculadora (Excel)</a>
        </div>
      </div>
    </section>
    <section id="beneficios" className="section" style={{background:'#F9FAFB'}}>
      <div className="container grid grid-4">
        {[['7–12 días','Envío aéreo HK→Lima'],['Genuino','Sin bloqueos regionales'],['8–20% menos','vs retail local'],['DOA 7 días','en electrónicos']].map(([t,d]) => (
          <div key={t} className="card" style={{textAlign:'center'}}><div style={{fontWeight:800,fontSize:20}}>{t}</div><div style={{color:'#6B7280'}}>{d}</div></div>
        ))}
      </div>
    </section>
    <section id="como" className="section">
      <div className="container"><h2>Cómo funciona</h2>
        <div className="grid grid-4" style={{marginTop:16}}>
          {[['Cotiza','Producto, qty y urgencia.'],['Proforma','Costo + flete + tiempos reales.'],['Compra y vuelo','Consolidamos y embarcamos.'],['Entrega y soporte','Control visual + DOA.']].map(([t,d],i)=> (
            <div key={t} className="card"><div style={{color:'#6B7280'}}>Paso {i+1}</div><div style={{fontWeight:800}}>{t}</div><div style={{color:'#6B7280'}}>{d}</div></div>
          ))}
        </div>
      </div>
    </section>
    <section id="servicios" className="section">
      <div className="container grid grid-2">
        <div className="card"><div style={{color:brand.blue,fontWeight:700,fontSize:12}}>B2B — Mayorista</div><h3>Suministro para sellers y tiendas</h3>
          <ul style={{lineHeight:1.8,color:'#374151'}}>
            <li>• Negociación con proveedor y consolidación.</li>
            <li>• Flete real (aéreo/marítimo) + handling.</li>
            <li>• Pagos 50/50; documentación (guía aérea/BL, factura).</li>
            <li>• Ahorros 8–20% según categoría/volumen.</li>
          </ul>
          <a className="btn btn-primary" href="https://wa.me/51929554806" target="_blank" rel="noreferrer">Cotizar B2B</a>
        </div>
        <div className="card"><div style={{color:brand.neon,fontWeight:700,fontSize:12}}>B2C — Personal shopper</div><h3>Traemos tu producto exacto</h3>
          <ul style={{lineHeight:1.8,color:'#374151'}}>
            <li>• Precio claro: costo + comisión + envío 13%.</li>
            <li>• Asesoría en tallas/compatibilidades.</li>
            <li>• Seguimiento por WhatsApp; entrega rápida.</li>
          </ul>
          <a className="btn btn-outline" href="https://wa.me/51929554806" target="_blank" rel="noreferrer">Cotizar B2C</a>
        </div>
      </div>
    </section>
    <section id="politicas" className="section" style={{background:'#F9FAFB'}}>
      <div className="container grid grid-3">
        <div className="card"><div style={{color:brand.blue,fontWeight:700,fontSize:12}}>Producto</div><p>Productos genuinos y liberados. Sin cambios por talla o preferencia. Asesoría previa para elegir bien.</p></div>
        <div className="card"><div style={{color:brand.blue,fontWeight:700,fontSize:12}}>Garantía</div><p>Electrónicos con DOA 7 días. Accesorios sin garantía por desgaste salvo falla reportada en 48 h.</p></div>
        <div className="card"><div style={{color:brand.blue,fontWeight:700,fontSize:12}}>Envíos</div><p>B2C aplica envío 13% del producto. B2B: flete real + handling. Seguimiento por WhatsApp.</p></div>
      </div>
    </section>
    <section id="contacto" className="section">
      <div className="container grid grid-2">
        <div><h2>Contacto</h2><p>¿Listo para cotizar? Escríbenos por WhatsApp o envíanos el formulario y te respondemos pronto.</p>
          <a className="btn btn-primary" href="https://wa.me/51929554806" target="_blank" rel="noreferrer">WhatsApp +51 929 554 806</a></div>
        <div className="card"><h3 style={{marginTop:0}}>Envíanos un mensaje</h3>
          <form method="POST" action="https://formsubmit.co/dmoralescanduelas@gmail.com">
            <input type="hidden" name="_next" value="/thankyou.html" />
            <input type="hidden" name="_subject" value="Nuevo mensaje desde Importaciones DINAMO" />
            <input type="hidden" name="_captcha" value="false" />
            <label>Nombre<input required name="nombre" /></label>
            <label>Correo<input required type="email" name="correo" /></label>
            <label>Mensaje<textarea rows="4" required name="mensaje"></textarea></label>
            <button className="btn btn-primary" type="submit">Enviar mensaje ✉️</button>
          </form>
        </div>
      </div>
    </section>
    <footer><div className="container" style={{padding:'24px 16px',display:'grid',gap:8}}>
      <div style={{fontWeight:800}}>Importaciones <span style={{color:brand.neon}}>DINAMO</span></div>
      <div style={{fontSize:14,opacity:.9}}>Energía que mueve tus negocios ⚡ — De Hong Kong a Lima en 7–12 días ✈️</div>
      <div style={{fontSize:14,opacity:.9}}>📧 dmoralescanduelas@gmail.com | 📱 +51 929 554 806 | IG: @importaciones_dinamo</div>
      <div style={{fontSize:12,opacity:.6}}>© {new Date().getFullYear()} Importaciones DINAMO. Todos los derechos reservados.</div>
    </div></footer>
  </div>);
}