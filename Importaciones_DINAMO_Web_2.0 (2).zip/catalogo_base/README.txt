Edita productos.xlsx o productos.json con tus artículos. En la versión 3.0 conectaremos estos archivos a la web.
