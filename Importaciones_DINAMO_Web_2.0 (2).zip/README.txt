IMPORTACIONES DINAMO 2.0 — INSTRUCCIONES

1) SUBIR A VERCEL
- https://vercel.com/new → Upload Project → selecciona este ZIP.
- Framework: Create React App (auto).
- Al finalizar tendrás: https://importaciones-dinamo.vercel.app

2) EDITAR WHATSAPP O CORREO
- WhatsApp: busca en src/App.jsx '51929554806' y reemplaza si cambia.
- Correo del formulario (FormSubmit): en src/App.jsx cambia la acción si quieres otro email.

3) DOMINIO PROPIO (OPCIONAL)
- Vercel → Project → Settings → Domains → Add Domain.
- DNS en tu proveedor: A @ → 76.76.21.21 | CNAME www → cname.vercel-dns.com

4) ERRORES COMUNES
- 'react-scripts build exited with 127' → mantener react-scripts 5.0.1 y redeploy.
- 'Could not read package.json' → asegúrate de subir el ZIP con package.json en la raíz.
- Dominio no detectado → revisa DNS o usa el dominio gratuito de Vercel.
- Formulario no envía → revisa el email de destino en el action del form.

5) SEO Y REDES
- Cambia title/description en public/index.html si deseas.
- Pon el link en tu bio de Instagram/WhatsApp Business.

6) MEDIR RESULTADOS EN INSTAGRAM
- Usa cuenta Profesional/Empresa, vincúlala a Facebook Business.
- Revisa semanalmente: Visitas al perfil, Clics en el enlace, Interacciones y Seguidores ganados.
