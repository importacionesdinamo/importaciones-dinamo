import React, { useState } from "react";

export default function App() {
  const [name, setName] = useState("");
  const [product, setProduct] = useState("");
  const [qty, setQty] = useState("");

  const sendWhatsApp = () => {
    const msg = `Hola, soy ${name}. Quiero cotizar ${product} (cantidad: ${qty}).`;
    const url = `https://wa.me/51929554806?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  };

  return (
    <div style={{ fontFamily: "Arial", textAlign: "center", marginTop: "80px" }}>
      <h1>Importaciones DINAMO</h1>
      <p>Traemos productos genuinos desde Hong Kong a Lima en 7–12 días.</p>
      <input placeholder="Tu nombre" onChange={(e) => setName(e.target.value)} /><br/><br/>
      <input placeholder="Producto" onChange={(e) => setProduct(e.target.value)} /><br/><br/>
      <input placeholder="Cantidad" onChange={(e) => setQty(e.target.value)} /><br/><br/>
      <button onClick={sendWhatsApp}>Cotizar por WhatsApp</button>
    </div>
  );
}
